/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_img_pixel_put.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/29 17:42:25 by causilva          #+#    #+#             */
/*   Updated: 2025/09/02 14:16:58 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft_mlx.h"

void	ft_img_pixel_put(t_img *img, t_coord pos, unsigned int color)
{
	char	*dst;

	dst = img->addr + (pos.y * img->line_length + pos.x * (img->bpp / 8));
	*(unsigned int *)dst = color;
}
/* 
void	ft_img_pixel_put(t_img *img, t_coord pos, unsigned int color)
{
	char	*dst;
	float	a;
	unsigned int	r;
	unsigned int	g;
	unsigned int	b;

	dst = img->addr + (pos.y * img->line_length + pos.x * (img->bpp / 8));
	a = (float)(color >> 24) / 255;
	r = ((color >> 16) & 0xFF) * a;
	r += ((*(unsigned int *)dst >> 16) & 0xFF) * (a - 1);
	g = ((color >> 8) & 0xFF) * a;
	g += ((*(unsigned int *)dst >> 8) & 0xFF) * (a - 1);
	b = ((color >> 0) & 0xFF) * a;
	b += ((*(unsigned int *)dst >> 0) & 0xFF) * (a - 1);
	*(unsigned int *)dst = (0xFF << 24 | r << 16 | g << 8 | b);
}
 */
/* 
// The last one assumes dst_alpha == 0xFF
void	my_mlx_pixel_put(t_img *img, t_coord pos, int color)
{
	char	*dst;
	float	a[3];
	unsigned int	r[3];
	unsigned int	g[3];
	unsigned int	b[3];

	dst = img->addr + (pos.y * img->line_length + pos.x * (img->bpp / 8));
	a[0] = (float)(*(unsigned int *)dst >> 24) / 255;
	r[0] = ((*(unsigned int *)dst >> 16) & 0xFF) * a[0];
	g[0] = ((*(unsigned int *)dst >> 8) & 0xFF) * a[0];
	b[0] = ((*(unsigned int *)dst >> 0) & 0xFF) * a[0];
	a[1] = (float)(color >> 24) / 255;
	r[1] = ((color >> 16) & 0xFF) * a[1];
	g[1] = ((color >> 8) & 0xFF) * a[1];
	b[1] = ((color >> 0) & 0xFF) * a[1];
	a[2] = a[0] + a[1] - (a[0] * a[1]);
	if (!a[2])
		return ;
	r[2] = (r[0] * (1 - a[1]) + r[1]) / a[2];
	g[2] = (g[0] * (1 - a[1]) + g[1]) / a[2];
	b[2] = (b[0] * (1 - a[1]) + b[1]) / a[2];
	*(unsigned int *)dst = ((unsigned int)(a[2] * 255) << 24);
	*(unsigned int *)dst |= (r[2] << 16 | g[2] << 8 | b[2]);
}
 */