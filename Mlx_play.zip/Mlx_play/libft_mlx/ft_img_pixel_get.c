/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_img_pixel_get.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/29 17:42:22 by causilva          #+#    #+#             */
/*   Updated: 2025/09/02 11:32:14 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft_mlx.h"

unsigned int	ft_img_pixel_get(t_img *img, t_coord pos)
{
	char	*dst;

	dst = img->addr + (pos.y * img->line_length + pos.x * (img->bpp / 8));
	return (*(unsigned int *)dst);
}
