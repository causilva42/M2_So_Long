/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/27 15:37:02 by causilva          #+#    #+#             */
/*   Updated: 2025/08/28 13:44:53 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	ft_strcmp(const char *s1, const char *s2)
{
	size_t	i;

	i = 0;
	while (1)
	{
		if (s1[i] == '\0' && s2[i] == '\0')
			return (0);
		if (((unsigned char *) s1)[i] != ((unsigned char *) s2)[i])
			return (((unsigned char *) s1)[i] - ((unsigned char *) s2)[i]);
		i++;
	}
	return (0);
}

int	ft_strlen(const char *s)
{
	int	i;

	i = 0;
	while (s[i] != '\0')
		i++;
	return (i);
}

char	*ft_strjoin(char const *s1, char const *s2)
{
	char	*string;
	int		len1;
	int		len2;

	if (!s1 && !s2)
		return (NULL);
	if (!s1)
		return (ft_strdup(s2));
	if (!s2)
		return (ft_strdup(s1));
	len1 = ft_strlen(s1);
	len2 = ft_strlen(s2);
	string = (char *) malloc((len1 + len2 + 1) * sizeof(char));
	if (!string)
		return (NULL);
	ft_strlcpy(string, s1, len1 + 1);
	ft_strlcat(string, s2, len1 + len2 + 1);
	return (string);
}

char	*ft_strdup(const char *s)
{
	size_t	size;
	char	*string;

	size = ft_strlen(s) + 1;
	string = (char *) malloc(size);
	if (!string)
		return (NULL);
	ft_strlcpy(string, s, size);
	return (string);
}

size_t	ft_strlcpy(char *dst, const char *src, size_t size)
{
	size_t	i;

	if (size == 0)
		return (ft_strlen(src));
	i = 0;
	while (src[i] != '\0' && i < size - 1)
	{
		dst[i] = (char) src[i];
		i++;
	}
	dst[i] = '\0';
	return (ft_strlen(src));
}

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	size_t	i;

	i = 0;
	while (dst[i] != '\0')
	{
		if (i == size)
			return (i + ft_strlen(src));
		i++;
	}
	if (i == size)
		return (i + ft_strlen(src));
	return (i + ft_strlcpy(&dst[i], src, size - i));
}

char	*ft_rmbreak(char *s)
{
	int	len;

	if (s)
	{
		len = ft_strlen(s);
		if (s[len - 1] == '\n')
			s[len - 1] = '\0';
	}
	return (s);
}
