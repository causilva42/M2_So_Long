/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/15 09:41:48 by causilva          #+#    #+#             */
/*   Updated: 2025/08/27 17:48:03 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	init_vars(t_vars *vars, char *filename);

int	main(int argc, char **argv)
{
	t_vars	vars;
	int		i;

	if (argc != 2)
		return (ft_printf("Error\nMain: Number of args != 2\n"), 1);
	if (init_vars(&vars, argv[1]) == -1)
		return (1);
	i = 0;
	while (i < vars.map.size.y)
	{
		write(1, &vars.map.data[i * vars.map.size.x], vars.map.size.x);
		ft_printf("\n");
		i++;
	}
	ft_printf("Player: (%d,%d)\n", vars.map.player.x, vars.map.player.y);
	ft_printf("Exit: (%d,%d)\n", vars.map.exit.x, vars.map.exit.y);
	ft_printf("collectibles: %d\n", vars.map.collectibles_count);
	free(vars.map.data);
	return (0);
}

int	init_vars(t_vars *vars, char *filename)
{
	if (parse_map(&(vars->map), filename) == -1)
		return (-1);
	return (0);
}
